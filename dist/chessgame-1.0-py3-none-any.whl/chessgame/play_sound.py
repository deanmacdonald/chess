from playsound import playsound

playsound("move_sound.mp3")  # Plays a sound file
